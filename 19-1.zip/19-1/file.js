alert('external js loaded')
alert("hello spandana")
