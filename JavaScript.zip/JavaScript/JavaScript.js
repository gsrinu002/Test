document.write("<h1>Message from javascript</h1>");
